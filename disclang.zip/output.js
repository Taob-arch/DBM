const Discord = require('discord.js');
const bot = new Discord.Client({disableeveryone: true});
bot.on('message', message =>{
const args = message.content.slice(1).trim().split(/ +/g);
command = message.content.toLowerCase()
SendMessage=(text) => message.channel.send(text)
if(command.startsWith("?" + "whale")){
SendMessage("I love whales");
SendMessage("But i hate whales");
}
if(command.startsWith("?" + "ban")){
message.guild.members.ban(message.mentions.users.first().id)
var member = message.mentions.users.first().id
SendMessage(member + " Has been BANNED")
}
if(command.startsWith("?" + "kick")){
message.guild.members.kick(message.mentions.users.first().id)
var member = message.mentions.users.first().id
SendMessage(member + "Has been KICKED")
}
})
bot.login("ODIzNjYyNTU4NzgzMzQwNTk0.YFkFiA.Uof109933RpbtjttpnRfX4eoU_E");
