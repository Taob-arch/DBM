var childProcess = require('child_process');
const fs = require('fs');
var numoffiles = 0;
var config = {
    "prefix":"?",
    "token":""
}

var finished = 0;

function mainBody(){
    clearOutput()
    output("const Discord = require('discord.js');")
    output("const bot = new Discord.Client({disableeveryone: true});");
    output("bot.on('message', message =>{")
    output("const args = message.content.slice(" + config.prefix.length + ").trim().split(/ +/g);")
    output("command = message.content.toLowerCase()")
    output("SendMessage=(text) => message.channel.send(text)")
    fs.readdir(__dirname + "/commands", function (err, files) {
        //handling error
        if (err) {
            return console.log('Unable to scan directory: ' + err);
        } 
        //listing all files using forEach
        files.forEach(function (file) {
            var permsneeded = {}
            numoffiles = numoffiles + 1;
            fs.readFile(__dirname + "/commands/" + file, 'utf8', function(err, data) { //C:\Users\emera\Desktop\disclang\commands\command1
                if (err) throw err;
                var lines = data.split('\r\n')
                output('if(command.startsWith("' + config.prefix + '" + "' + lines[0].replace('[]', '') +'")){')
                var loop = true;
                var i = 1;
                while(loop){
                    if(lines[i].startsWith('<>end')){
                        loop = false
                        output("}")
                        finished + 1;
                    }
                    else{
                        console.log(lines[i])
                        if(lines[i].startsWith("Send(")){
                            console.log("SendCommand")
                            var quotesplit = lines[i].split('"')
                            output('SendMessage("' + quotesplit[1] + '");')
                            console.log(quotesplit[1])
                        }
                        if(lines[i].startsWith('^')){
                            output("if (!message.member.hasPermission('" + lines[i].replace('^', '') + "')) {return;}")
                        }
                        if(lines[i].startsWith('$%')){
                            output(lines[i].replace('$%', ''))
                        }
                        if(lines[i] == "BanMention()"){
                            output("message.guild.members.ban(message.mentions.users.first().id)")
                        }
                        if(lines[i] == "KickMention()"){
                            output("message.guild.members.kick(message.mentions.users.first().id)")
                        }
                    }
                    i++;
                }
            });
        });
    });
}
mainBody()

function output(data){
    fs.appendFileSync('./output.js', data + "\r\n", (err) => {
    })
}

function clearOutput(){
    fs.writeFileSync('./output.js', '', (err) =>{
    })
}

function runScript(scriptPath, callback) {
    var invoked = false;
    var process = childProcess.fork(scriptPath);
    process.on('error', function (err) {
        if (invoked) return;
        invoked = true;
        callback(err);
    });
    process.on('exit', function (code) {
        if (invoked) return;
        invoked = true;
        var err = code === 0 ? null : new Error('exit code ' + code);
        callback(err);
    });
}

process.on('exit', function (){
    output("})")
    output('bot.login("' + config.token + '");')
});